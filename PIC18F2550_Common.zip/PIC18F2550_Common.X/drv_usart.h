#ifndef DRV_USART_H
#define	DRV_USART_H

#ifdef	__cplusplus
extern "C" {
#endif
#include "common.h"
    
void USART_init(void);
void testSendUSART(uint32,uint8);



#ifdef	__cplusplus
}
#endif

#endif	/* DRV_USART_H */

