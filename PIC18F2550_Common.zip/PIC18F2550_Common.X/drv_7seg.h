/* 
 * File:   7segment.h
 * Author: SaPA
 *
 * Created on 14 �������� 2024 �., 16:55
 */

#ifndef SEVEN_SEGMENT_H
#define	SEVEN_SEGMENT_H

#ifdef	__cplusplus
extern "C" {
#endif
#include "common.h"

    
    
void DigToSeg (uint8, uint8);    
void Display (uint16);

#ifdef	__cplusplus
}
#endif

#endif	/* 7SEGMENT_H */

